"use client";

import React, { useState, useEffect } from "react";
import {
  LayoutDashboard,
  Users,
  Building2,
  Handshake,
  Bell,
  Plus,
  X,
  Trash2,
  Pencil,
  Check,
  AlertTriangle,
  ChevronRight,
  RotateCcw,
  UploadCloud,
  CheckCircle2,
  LogOut,
} from "lucide-react";
import { SEED_PLAYERS, SEED_CONTACTS, SEED_DEALS, SEED_REMINDERS } from "@/lib/seedData";
import { listTable, insertRow, insertMany, updateRow, deleteRow } from "@/lib/api";
import { useRouter } from "next/navigation";

const POSITIONS = [
  "Gardien",
  "Défenseur central",
  "Latéral droit",
  "Latéral gauche",
  "Milieu défensif",
  "Milieu central",
  "Milieu offensif",
  "Excentré droit",
  "Excentré gauche",
  "Piston droit",
  "Piston gauche",
  "Ailier droit",
  "Ailier gauche",
  "Attaquant",
];

const CATEGORIES = [
  { key: "Pro", label: "Joueurs pro" },
  { key: "Suivi", label: "Suivis / prospects" },
  { key: "Jeune", label: "Centre de formation" },
];

const STAGES = [
  { key: "Prospection", color: "bg-slate-500" },
  { key: "Premier contact", color: "bg-sky-500" },
  { key: "Négociation", color: "bg-amber-500" },
  { key: "Offre envoyée", color: "bg-orange-500" },
  { key: "Signé", color: "bg-emerald-500" },
  { key: "Perdu", color: "bg-rose-500" },
];

const REMINDER_TYPES = ["Échéance contrat", "Relance", "Rendez-vous", "Autre"];

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function formatDate(d) {
  if (!d) return "—";
  try {
    return new Date(d + "T00:00:00").toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  } catch (e) {
    return d;
  }
}

function daysUntil(d) {
  if (!d) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(d + "T00:00:00");
  return Math.round((target - today) / 86400000);
}

function urgencyColor(days) {
  if (days === null) return "text-slate-400";
  if (days < 0) return "text-rose-400";
  if (days <= 30) return "text-rose-400";
  if (days <= 90) return "text-amber-400";
  return "text-slate-400";
}

function Field({ label, children }) {
  return (
    <label className="block mb-3">
      <span className="block text-xs uppercase tracking-wide text-slate-400 mb-1 font-semibold">
        {label}
      </span>
      {children}
    </label>
  );
}

const inputCls =
  "w-full bg-slate-800 border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500";

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <h3 className="font-['Oswald'] text-lg tracking-wide text-slate-100">
            {title}
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100 transition-colors"
            aria-label="Fermer"
          >
            <X size={20} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function StatCard({ label, value, accent, icon: Icon }) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
      <div className={`rounded-lg p-2.5 ${accent}`}>
        <Icon size={20} className="text-slate-950" />
      </div>
      <div>
        <div className="font-mono text-2xl font-semibold text-slate-100 leading-none">
          {value}
        </div>
        <div className="text-xs text-slate-400 mt-1">{label}</div>
      </div>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [players, setPlayers] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [deals, setDeals] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saveError, setSaveError] = useState(false);
  const router = useRouter();

  useEffect(() => {
    (async () => {
      try {
        const [p, c, d, r] = await Promise.all([
          listTable("players"),
          listTable("contacts"),
          listTable("deals"),
          listTable("reminders"),
        ]);
        setPlayers(p);
        setContacts(c);
        setDeals(d);
        setReminders(r);
      } catch (e) {
        console.error(e);
        setSaveError(true);
      }
      setLoading(false);
    })();
  }, []);

  const collections = {
    players: [players, setPlayers],
    contacts: [contacts, setContacts],
    deals: [deals, setDeals],
    reminders: [reminders, setReminders],
  };

  async function addItem(key, item) {
    const [state, setState] = collections[key];
    try {
      const saved = await insertRow(key, item);
      setState([...state, saved]);
    } catch (e) {
      console.error(e);
      setSaveError(true);
    }
  }
  async function updateItem(key, id, patch) {
    const [state, setState] = collections[key];
    try {
      const saved = await updateRow(key, id, patch);
      setState(state.map((it) => (it.id === id ? saved : it)));
    } catch (e) {
      console.error(e);
      setSaveError(true);
    }
  }
  async function deleteItem(key, id) {
    const [state, setState] = collections[key];
    try {
      await deleteRow(key, id);
      setState(state.filter((it) => it.id !== id));
    } catch (e) {
      console.error(e);
      setSaveError(true);
    }
  }
  // Used by the bulk import: inserts many rows at once and skips any whose
  // name/title already exists locally, to avoid duplicating on re-import.
  async function importMany(key, items, dedupeKey) {
    const [state, setState] = collections[key];
    const existing = new Set(state.map((it) => (dedupeKey(it) || "").toLowerCase()));
    const fresh = items.filter((it) => !existing.has((dedupeKey(it) || "").toLowerCase()));
    if (fresh.length === 0) return 0;
    try {
      const saved = await insertMany(key, fresh);
      setState([...state, ...saved]);
      return saved.length;
    } catch (e) {
      console.error(e);
      setSaveError(true);
      return 0;
    }
  }
  async function resetAll() {
    if (!window.confirm("Effacer toutes les données du CRM ? Cette action est irréversible pour toute l'équipe.")) return;
    try {
      await Promise.all([
        ...players.map((p) => deleteRow("players", p.id)),
        ...contacts.map((c) => deleteRow("contacts", c.id)),
        ...deals.map((d) => deleteRow("deals", d.id)),
        ...reminders.map((r) => deleteRow("reminders", r.id)),
      ]);
      setPlayers([]);
      setContacts([]);
      setDeals([]);
      setReminders([]);
    } catch (e) {
      console.error(e);
      setSaveError(true);
    }
  }
  async function logout() {
    await fetch("/api/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  const navItems = [
    { key: "dashboard", label: "Tableau de bord", icon: LayoutDashboard },
    { key: "players", label: "Joueurs", icon: Users },
    { key: "contacts", label: "Clubs & contacts", icon: Building2 },
    { key: "deals", label: "Négociations", icon: Handshake },
    { key: "reminders", label: "Rappels", icon: Bell },
    { key: "import", label: "Import Excel", icon: UploadCloud },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex font-sans">
      {saveError && (
        <div className="fixed top-3 right-3 z-50 bg-rose-950/90 border border-rose-800 text-rose-200 text-sm px-4 py-2 rounded-md">
          Problème de connexion à la base de données — vérifie ta configuration Supabase.
        </div>
      )}

      {/* Sidebar */}
      <aside className="w-60 shrink-0 bg-slate-900 border-r border-slate-800 flex flex-col">
        <div className="px-5 py-6 border-b border-slate-800">
          <div className="font-['Oswald'] text-xl tracking-wide text-slate-100">
            PIVOT<span className="text-emerald-500">.</span>
          </div>
          <div className="text-xs text-slate-500 mt-0.5">Agence de joueurs</div>
        </div>
        <nav className="flex-1 py-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = tab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setTab(item.key)}
                className={`w-full flex items-center gap-3 px-5 py-3 text-sm transition-colors border-l-2 ${
                  active
                    ? "bg-slate-800/60 border-emerald-500 text-slate-100"
                    : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
                }`}
              >
                <Icon size={17} />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="px-5 py-4 border-t border-slate-800 space-y-2">
          <button
            onClick={resetAll}
            className="flex items-center gap-2 text-xs text-slate-500 hover:text-rose-400 transition-colors"
          >
            <RotateCcw size={14} />
            Réinitialiser les données
          </button>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-xs text-slate-500 hover:text-slate-200 transition-colors"
          >
            <LogOut size={14} />
            Se déconnecter
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 min-w-0 p-6 md:p-8 overflow-y-auto">
        {loading ? (
          <div className="text-slate-400 text-sm">Chargement des données…</div>
        ) : (
          <>
            {tab === "dashboard" && (
              <Dashboard players={players} deals={deals} reminders={reminders} />
            )}
            {tab === "players" && (
              <PlayersTab
                players={players}
                addItem={addItem}
                updateItem={updateItem}
                deleteItem={deleteItem}
              />
            )}
            {tab === "contacts" && (
              <ContactsTab
                contacts={contacts}
                addItem={addItem}
                updateItem={updateItem}
                deleteItem={deleteItem}
              />
            )}
            {tab === "deals" && (
              <DealsTab
                deals={deals}
                players={players}
                addItem={addItem}
                updateItem={updateItem}
                deleteItem={deleteItem}
              />
            )}
            {tab === "reminders" && (
              <RemindersTab
                reminders={reminders}
                players={players}
                addItem={addItem}
                updateItem={updateItem}
                deleteItem={deleteItem}
              />
            )}
            {tab === "import" && (
              <ImportTab
                players={players}
                contacts={contacts}
                deals={deals}
                reminders={reminders}
                importMany={importMany}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}

function PageHeader({ title, subtitle, action }) {
  return (
    <div className="flex items-start justify-between mb-6 gap-4">
      <div>
        <h1 className="font-['Oswald'] text-2xl tracking-wide text-slate-100">
          {title}
        </h1>
        {subtitle && <p className="text-sm text-slate-400 mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

function AddButton({ onClick, label }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 transition-colors text-slate-950 font-semibold text-sm px-4 py-2 rounded-md"
    >
      <Plus size={16} />
      {label}
    </button>
  );
}

/* ---------------- Dashboard ---------------- */

function Dashboard({ players, deals, reminders }) {
  const activeDeals = deals.filter((d) => d.stage !== "Signé" && d.stage !== "Perdu");
  const expiringSoon = players
    .filter((p) => p.contractEnd && daysUntil(p.contractEnd) !== null && daysUntil(p.contractEnd) <= 180)
    .sort((a, b) => daysUntil(a.contractEnd) - daysUntil(b.contractEnd));
  const upcomingReminders = reminders
    .filter((r) => !r.done && r.dueDate)
    .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
    .slice(0, 6);

  return (
    <div>
      <PageHeader title="Tableau de bord" subtitle="Vue d'ensemble de votre portefeuille" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatCard label="Joueurs représentés" value={players.length} accent="bg-emerald-500" icon={Users} />
        <StatCard label="Négociations actives" value={activeDeals.length} accent="bg-amber-500" icon={Handshake} />
        <StatCard label="Contrats < 6 mois" value={expiringSoon.length} accent="bg-rose-500" icon={AlertTriangle} />
        <StatCard label="Rappels à venir" value={upcomingReminders.length} accent="bg-sky-500" icon={Bell} />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <h3 className="font-['Oswald'] text-base tracking-wide mb-4 text-slate-200">
            Contrats à surveiller
          </h3>
          {expiringSoon.length === 0 ? (
            <p className="text-sm text-slate-500">Aucun contrat n'arrive à échéance dans les 6 prochains mois.</p>
          ) : (
            <ul className="space-y-3">
              {expiringSoon.slice(0, 6).map((p) => {
                const d = daysUntil(p.contractEnd);
                return (
                  <li key={p.id} className="flex items-center justify-between text-sm">
                    <span className="text-slate-200">{p.name}</span>
                    <span className={`font-mono text-xs ${urgencyColor(d)}`}>
                      {formatDate(p.contractEnd)} · {d < 0 ? "expiré" : `${d} j`}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <h3 className="font-['Oswald'] text-base tracking-wide mb-4 text-slate-200">
            Prochains rappels
          </h3>
          {upcomingReminders.length === 0 ? (
            <p className="text-sm text-slate-500">Aucun rappel programmé.</p>
          ) : (
            <ul className="space-y-3">
              {upcomingReminders.map((r) => {
                const d = daysUntil(r.dueDate);
                return (
                  <li key={r.id} className="flex items-center justify-between text-sm">
                    <div>
                      <span className="text-slate-200">{r.title}</span>
                      <span className="text-slate-500 text-xs ml-2">{r.type}</span>
                    </div>
                    <span className={`font-mono text-xs ${urgencyColor(d)}`}>
                      {formatDate(r.dueDate)}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Players ---------------- */

function PlayersTab({ players, addItem, updateItem, deleteItem }) {
  const [modal, setModal] = useState(null); // null | 'new' | player.id
  const [filter, setFilter] = useState("all");

  const editing = modal && modal !== "new" ? players.find((p) => p.id === modal) : null;
  const visible = filter === "all" ? players : players.filter((p) => (p.category || "Pro") === filter);

  return (
    <div>
      <PageHeader
        title="Joueurs"
        subtitle={`${players.length} joueur${players.length > 1 ? "s" : ""} au total`}
        action={<AddButton onClick={() => setModal("new")} label="Ajouter un joueur" />}
      />

      <div className="flex gap-2 mb-5 flex-wrap">
        <button
          onClick={() => setFilter("all")}
          className={`text-xs px-3 py-1.5 rounded-full border ${filter === "all" ? "bg-emerald-600 border-emerald-600 text-slate-950 font-semibold" : "border-slate-700 text-slate-400 hover:text-slate-200"}`}
        >
          Tous ({players.length})
        </button>
        {CATEGORIES.map((c) => {
          const count = players.filter((p) => (p.category || "Pro") === c.key).length;
          return (
            <button
              key={c.key}
              onClick={() => setFilter(c.key)}
              className={`text-xs px-3 py-1.5 rounded-full border ${filter === c.key ? "bg-emerald-600 border-emerald-600 text-slate-950 font-semibold" : "border-slate-700 text-slate-400 hover:text-slate-200"}`}
            >
              {c.label} ({count})
            </button>
          );
        })}
      </div>

      {visible.length === 0 ? (
        <EmptyState text="Aucun joueur dans cette catégorie." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {visible.map((p) => {
            const d = daysUntil(p.contractEnd);
            return (
              <div key={p.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-['Oswald'] text-lg text-slate-100 tracking-wide">{p.name}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-emerald-400 font-semibold">{p.position}</span>
                      <span className="text-xs text-slate-600">·</span>
                      <span className="text-xs text-slate-500">{p.category || "Pro"}</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => setModal(p.id)} className="text-slate-500 hover:text-slate-200 p-1">
                      <Pencil size={14} />
                    </button>
                    <button onClick={() => deleteItem("players", p.id)} className="text-slate-500 hover:text-rose-400 p-1">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
                <div className="mt-3 text-sm text-slate-400 space-y-1 flex-1">
                  {p.age && <div>Âge : {p.age} ans{p.nationality ? ` · ${p.nationality}` : ""}</div>}
                  {p.currentClub && <div>Club : {p.currentClub}{p.niveau ? ` (${p.niveau})` : ""}</div>}
                  {p.marketValue && <div>Valeur estimée : {p.marketValue}</div>}
                  {p.phone && <div className="font-mono text-xs">{p.phone}</div>}
                </div>
                {p.contractEnd && (
                  <div className={`mt-3 pt-3 border-t border-slate-800 font-mono text-xs ${urgencyColor(d)}`}>
                    Fin de contrat : {formatDate(p.contractEnd)} {d !== null && `(${d < 0 ? "expiré" : d + " j"})`}
                  </div>
                )}
                {p.notes && <div className="mt-2 text-xs text-slate-500 italic">{p.notes}</div>}
              </div>
            );
          })}
        </div>
      )}

      {modal && (
        <PlayerForm
          player={editing}
          onClose={() => setModal(null)}
          onSave={async (data) => {
            if (editing) await updateItem("players", editing.id, data);
            else await addItem("players", data);
            setModal(null);
          }}
        />
      )}
    </div>
  );
}

function PlayerForm({ player, onClose, onSave }) {
  const [form, setForm] = useState(
    player || {
      name: "",
      category: "Pro",
      position: POSITIONS[0],
      age: "",
      nationality: "",
      currentClub: "",
      niveau: "",
      contractStart: "",
      contractEnd: "",
      marketValue: "",
      phone: "",
      notes: "",
    }
  );
  return (
    <Modal title={player ? "Modifier le joueur" : "Nouveau joueur"} onClose={onClose}>
      <Field label="Nom">
        <input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex. Nathan Diarra" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Catégorie">
          <select className={inputCls} value={form.category || "Pro"} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            {CATEGORIES.map((c) => (
              <option key={c.key} value={c.key}>{c.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Poste">
          <select className={inputCls} value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })}>
            {POSITIONS.map((pos) => (
              <option key={pos} value={pos}>{pos}</option>
            ))}
          </select>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Âge">
          <input type="number" className={inputCls} value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} />
        </Field>
        <Field label="Nationalité">
          <input className={inputCls} value={form.nationality} onChange={(e) => setForm({ ...form, nationality: e.target.value })} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Club actuel">
          <input className={inputCls} value={form.currentClub} onChange={(e) => setForm({ ...form, currentClub: e.target.value })} />
        </Field>
        <Field label="Niveau / championnat">
          <input className={inputCls} placeholder="Ex. Ligue 2" value={form.niveau} onChange={(e) => setForm({ ...form, niveau: e.target.value })} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Début de contrat">
          <input type="date" className={inputCls} value={form.contractStart} onChange={(e) => setForm({ ...form, contractStart: e.target.value })} />
        </Field>
        <Field label="Fin de contrat">
          <input type="date" className={inputCls} value={form.contractEnd} onChange={(e) => setForm({ ...form, contractEnd: e.target.value })} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Valeur estimée">
          <input className={inputCls} placeholder="Ex. 4 M€" value={form.marketValue} onChange={(e) => setForm({ ...form, marketValue: e.target.value })} />
        </Field>
        <Field label="Téléphone">
          <input className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </Field>
      </div>
      <Field label="Notes">
        <textarea className={inputCls} rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </Field>
      <div className="flex justify-end gap-2 mt-4">
        <button onClick={onClose} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200">Annuler</button>
        <button
          onClick={() => form.name.trim() && onSave(form)}
          className="px-4 py-2 text-sm bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold rounded-md"
        >
          Enregistrer
        </button>
      </div>
    </Modal>
  );
}

/* ---------------- Contacts ---------------- */

function ContactsTab({ contacts, addItem, updateItem, deleteItem }) {
  const [modal, setModal] = useState(null);
  const editing = modal && modal !== "new" ? contacts.find((c) => c.id === modal) : null;

  return (
    <div>
      <PageHeader
        title="Clubs & contacts"
        subtitle={`${contacts.length} contact${contacts.length > 1 ? "s" : ""} enregistré${contacts.length > 1 ? "s" : ""}`}
        action={<AddButton onClick={() => setModal("new")} label="Ajouter un contact" />}
      />

      {contacts.length === 0 ? (
        <EmptyState text="Aucun contact enregistré. Ajoutez un dirigeant ou un recruteur pour commencer." />
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-800/60 text-slate-400 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3 font-semibold">Club</th>
                <th className="text-left px-4 py-3 font-semibold">Contact</th>
                <th className="text-left px-4 py-3 font-semibold">Rôle</th>
                <th className="text-left px-4 py-3 font-semibold">Téléphone</th>
                <th className="text-left px-4 py-3 font-semibold">Email</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {contacts.map((c) => (
                <tr key={c.id} className="border-t border-slate-800 hover:bg-slate-800/30">
                  <td className="px-4 py-3 text-slate-100 font-medium">{c.clubName}</td>
                  <td className="px-4 py-3 text-slate-300">{c.contactName}</td>
                  <td className="px-4 py-3 text-slate-400">{c.role}</td>
                  <td className="px-4 py-3 text-slate-400 font-mono text-xs">{c.phone}</td>
                  <td className="px-4 py-3 text-slate-400">{c.email}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1 justify-end">
                      <button onClick={() => setModal(c.id)} className="text-slate-500 hover:text-slate-200 p-1"><Pencil size={14} /></button>
                      <button onClick={() => deleteItem("contacts", c.id)} className="text-slate-500 hover:text-rose-400 p-1"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modal && (
        <ContactForm
          contact={editing}
          onClose={() => setModal(null)}
          onSave={async (data) => {
            if (editing) await updateItem("contacts", editing.id, data);
            else await addItem("contacts", data);
            setModal(null);
          }}
        />
      )}
    </div>
  );
}

function ContactForm({ contact, onClose, onSave }) {
  const [form, setForm] = useState(
    contact || { clubName: "", contactName: "", role: "", phone: "", email: "", notes: "" }
  );
  return (
    <Modal title={contact ? "Modifier le contact" : "Nouveau contact"} onClose={onClose}>
      <Field label="Club">
        <input className={inputCls} value={form.clubName} onChange={(e) => setForm({ ...form, clubName: e.target.value })} />
      </Field>
      <Field label="Nom du contact">
        <input className={inputCls} value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} />
      </Field>
      <Field label="Rôle">
        <input className={inputCls} placeholder="Ex. Directeur sportif" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Téléphone">
          <input className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </Field>
        <Field label="Email">
          <input className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </Field>
      </div>
      <Field label="Notes">
        <textarea className={inputCls} rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </Field>
      <div className="flex justify-end gap-2 mt-4">
        <button onClick={onClose} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200">Annuler</button>
        <button
          onClick={() => form.clubName.trim() && onSave(form)}
          className="px-4 py-2 text-sm bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold rounded-md"
        >
          Enregistrer
        </button>
      </div>
    </Modal>
  );
}

/* ---------------- Deals / Pipeline ---------------- */

function DealsTab({ deals, players, addItem, updateItem, deleteItem }) {
  const [modal, setModal] = useState(null);
  const editing = modal && modal !== "new" ? deals.find((d) => d.id === modal) : null;

  return (
    <div>
      <PageHeader
        title="Négociations"
        subtitle="Pipeline des transferts et discussions en cours"
        action={<AddButton onClick={() => setModal("new")} label="Nouvelle négociation" />}
      />

      {deals.length === 0 ? (
        <EmptyState text="Aucune négociation en cours. Lancez-en une pour suivre un transfert." />
      ) : (
        <div className="flex gap-4 overflow-x-auto pb-2">
          {STAGES.map((stage) => {
            const stageDeals = deals.filter((d) => d.stage === stage.key);
            return (
              <div key={stage.key} className="w-64 shrink-0">
                <div className="flex items-center gap-2 mb-3">
                  <span className={`w-2 h-2 rounded-full ${stage.color}`} />
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    {stage.key}
                  </span>
                  <span className="text-xs text-slate-600 font-mono">{stageDeals.length}</span>
                </div>
                <div className="space-y-3">
                  {stageDeals.map((d) => (
                    <div key={d.id} className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                      <div className="flex items-start justify-between">
                        <div className="font-['Oswald'] text-sm text-slate-100 tracking-wide">{d.playerName}</div>
                        <div className="flex gap-1">
                          <button onClick={() => setModal(d.id)} className="text-slate-600 hover:text-slate-200 p-0.5"><Pencil size={12} /></button>
                          <button onClick={() => deleteItem("deals", d.id)} className="text-slate-600 hover:text-rose-400 p-0.5"><Trash2 size={12} /></button>
                        </div>
                      </div>
                      <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                        <ChevronRight size={11} /> {d.targetClub}
                      </div>
                      {d.value && <div className="text-xs font-mono text-amber-400 mt-1.5">{d.value}</div>}
                      {d.deadline && <div className="text-xs font-mono text-slate-500 mt-1">{formatDate(d.deadline)}</div>}
                      <select
                        value={d.stage}
                        onChange={(e) => updateItem("deals", d.id, { stage: e.target.value })}
                        className="mt-2 w-full bg-slate-800 border border-slate-700 rounded text-xs px-2 py-1 text-slate-300"
                      >
                        {STAGES.map((s) => (
                          <option key={s.key} value={s.key}>{s.key}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal && (
        <DealForm
          deal={editing}
          players={players}
          onClose={() => setModal(null)}
          onSave={async (data) => {
            if (editing) await updateItem("deals", editing.id, data);
            else await addItem("deals", data);
            setModal(null);
          }}
        />
      )}
    </div>
  );
}

function DealForm({ deal, players, onClose, onSave }) {
  const [form, setForm] = useState(
    deal || { playerName: "", targetClub: "", stage: "Prospection", value: "", deadline: "", notes: "" }
  );
  return (
    <Modal title={deal ? "Modifier la négociation" : "Nouvelle négociation"} onClose={onClose}>
      <Field label="Joueur">
        <input
          list="players-list"
          className={inputCls}
          value={form.playerName}
          onChange={(e) => setForm({ ...form, playerName: e.target.value })}
          placeholder="Nom du joueur"
        />
        <datalist id="players-list">
          {players.map((p) => (
            <option key={p.id} value={p.name} />
          ))}
        </datalist>
      </Field>
      <Field label="Club cible">
        <input className={inputCls} value={form.targetClub} onChange={(e) => setForm({ ...form, targetClub: e.target.value })} />
      </Field>
      <Field label="Étape">
        <select className={inputCls} value={form.stage} onChange={(e) => setForm({ ...form, stage: e.target.value })}>
          {STAGES.map((s) => (
            <option key={s.key} value={s.key}>{s.key}</option>
          ))}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Montant / conditions">
          <input className={inputCls} placeholder="Ex. 6 M€ + bonus" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
        </Field>
        <Field label="Échéance">
          <input type="date" className={inputCls} value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
        </Field>
      </div>
      <Field label="Notes">
        <textarea className={inputCls} rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </Field>
      <div className="flex justify-end gap-2 mt-4">
        <button onClick={onClose} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200">Annuler</button>
        <button
          onClick={() => form.playerName.trim() && form.targetClub.trim() && onSave(form)}
          className="px-4 py-2 text-sm bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold rounded-md"
        >
          Enregistrer
        </button>
      </div>
    </Modal>
  );
}

/* ---------------- Reminders ---------------- */

function RemindersTab({ reminders, players, addItem, updateItem, deleteItem }) {
  const [modal, setModal] = useState(null);
  const [showDone, setShowDone] = useState(false);
  const editing = modal && modal !== "new" ? reminders.find((r) => r.id === modal) : null;

  const visible = reminders
    .filter((r) => (showDone ? true : !r.done))
    .sort((a, b) => new Date(a.dueDate || 0) - new Date(b.dueDate || 0));

  return (
    <div>
      <PageHeader
        title="Rappels"
        subtitle="Échéances de contrat, relances et rendez-vous"
        action={<AddButton onClick={() => setModal("new")} label="Nouveau rappel" />}
      />

      <label className="flex items-center gap-2 text-sm text-slate-400 mb-4">
        <input type="checkbox" checked={showDone} onChange={(e) => setShowDone(e.target.checked)} />
        Afficher les rappels terminés
      </label>

      {visible.length === 0 ? (
        <EmptyState text="Aucun rappel à afficher." />
      ) : (
        <div className="space-y-2">
          {visible.map((r) => {
            const d = daysUntil(r.dueDate);
            return (
              <div
                key={r.id}
                className={`bg-slate-900 border border-slate-800 rounded-lg px-4 py-3 flex items-center justify-between ${r.done ? "opacity-50" : ""}`}
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => updateItem("reminders", r.id, { done: !r.done })}
                    className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                      r.done ? "bg-emerald-500 border-emerald-500" : "border-slate-600"
                    }`}
                  >
                    {r.done && <Check size={12} className="text-slate-950" />}
                  </button>
                  <div>
                    <div className={`text-sm text-slate-100 ${r.done ? "line-through" : ""}`}>{r.title}</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {r.type} {r.playerName && `· ${r.playerName}`}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`font-mono text-xs ${urgencyColor(d)}`}>{formatDate(r.dueDate)}</span>
                  <button onClick={() => setModal(r.id)} className="text-slate-500 hover:text-slate-200 p-1"><Pencil size={14} /></button>
                  <button onClick={() => deleteItem("reminders", r.id)} className="text-slate-500 hover:text-rose-400 p-1"><Trash2 size={14} /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal && (
        <ReminderForm
          reminder={editing}
          players={players}
          onClose={() => setModal(null)}
          onSave={async (data) => {
            if (editing) await updateItem("reminders", editing.id, data);
            else await addItem("reminders", { ...data, done: false });
            setModal(null);
          }}
        />
      )}
    </div>
  );
}

function ReminderForm({ reminder, players, onClose, onSave }) {
  const [form, setForm] = useState(
    reminder || { title: "", type: REMINDER_TYPES[0], dueDate: "", playerName: "", notes: "" }
  );
  return (
    <Modal title={reminder ? "Modifier le rappel" : "Nouveau rappel"} onClose={onClose}>
      <Field label="Titre">
        <input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex. Relancer l'OL pour Diarra" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Type">
          <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
            {REMINDER_TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="Date">
          <input type="date" className={inputCls} value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
        </Field>
      </div>
      <Field label="Joueur lié (optionnel)">
        <input list="players-list-r" className={inputCls} value={form.playerName} onChange={(e) => setForm({ ...form, playerName: e.target.value })} />
        <datalist id="players-list-r">
          {players.map((p) => (
            <option key={p.id} value={p.name} />
          ))}
        </datalist>
      </Field>
      <Field label="Notes">
        <textarea className={inputCls} rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </Field>
      <div className="flex justify-end gap-2 mt-4">
        <button onClick={onClose} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200">Annuler</button>
        <button
          onClick={() => form.title.trim() && onSave(form)}
          className="px-4 py-2 text-sm bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold rounded-md"
        >
          Enregistrer
        </button>
      </div>
    </Modal>
  );
}

/* ---------------- Import ---------------- */

function ImportTab({ players, contacts, deals, reminders, importMany }) {
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const [summary, setSummary] = useState(null);

  async function runImport() {
    setBusy(true);
    const [p, c, d, r] = await Promise.all([
      importMany("players", SEED_PLAYERS, (it) => it.name),
      importMany("contacts", SEED_CONTACTS, (it) => `${it.clubName}|${it.contactName}`),
      importMany("deals", SEED_DEALS, (it) => `${it.playerName}|${it.targetClub}`),
      importMany("reminders", SEED_REMINDERS, (it) => it.title),
    ]);
    setSummary({ players: p, contacts: c, deals: d, reminders: r });
    setDone(true);
    setBusy(false);
  }

  return (
    <div>
      <PageHeader title="Import Excel" subtitle="Données extraites de ton fichier Excellence Union CRM (.xlsx)" />

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6">
        <h3 className="font-['Oswald'] text-base tracking-wide mb-3 text-slate-200">Ce qui sera importé</h3>
        <ul className="text-sm text-slate-400 space-y-1.5 list-disc list-inside">
          <li>{SEED_PLAYERS.filter((p) => p.category === "Pro").length} joueurs pro (fiches complètes + contrats + commissions)</li>
          <li>{SEED_PLAYERS.filter((p) => p.category === "Suivi").length} joueurs suivis / prospects</li>
          <li>{SEED_PLAYERS.filter((p) => p.category === "Jeune").length} jeunes en centre de formation</li>
          <li>{SEED_DEALS.length} négociations en cours (demandes clubs avec joueur proposé)</li>
          <li>{SEED_CONTACTS.length} contacts clubs, sélections nationales et agences — France et international</li>
          <li>{SEED_REMINDERS.length} rappels identifiés dans le fichier</li>
        </ul>
        {!done ? (
          <button
            onClick={runImport}
            disabled={busy}
            className="mt-5 flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 transition-colors text-slate-950 font-semibold text-sm px-4 py-2 rounded-md"
          >
            <UploadCloud size={16} />
            {busy ? "Import en cours…" : "Lancer l'import"}
          </button>
        ) : (
          <div className="mt-5 flex items-center gap-2 text-emerald-400 text-sm">
            <CheckCircle2 size={16} />
            Import terminé : {summary.players} joueurs, {summary.contacts} contacts, {summary.deals} négociations, {summary.reminders} rappels ajoutés.
          </div>
        )}
        <p className="text-xs text-slate-500 mt-3">
          Les entrées déjà présentes dans ton CRM (même nom) ne sont pas dupliquées. Tu peux relancer l'import sans risque.
        </p>
      </div>

      <div className="bg-amber-950/30 border border-amber-900/50 rounded-xl p-5">
        <div className="flex items-start gap-3">
          <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
          <div>
            <h3 className="font-['Oswald'] text-base tracking-wide text-amber-200 mb-2">
              À vérifier après import
            </h3>
            <p className="text-sm text-slate-400 mb-2">
              Quelques incohérences existaient déjà dans le fichier source (date de naissance ou fin de contrat improbables pour Samy Chouchane, écarts de date pour Ricardo Coutinho et Mouez Hassen). Ces fiches sont marquées "⚠️" dans leurs notes — à corriger avec l'agent référent concerné.
            </p>
            <p className="text-sm text-slate-400">
              Les dizaines de propositions d'essais pour les jeunes du centre de formation n'ont pas été transformées en négociations individuelles (trop nombreuses pour le pipeline pro) — elles restent résumées dans les notes de chaque fiche jeune concernée.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ text }) {
  return (
    <div className="border border-dashed border-slate-800 rounded-xl p-10 text-center text-sm text-slate-500">
      {text}
    </div>
  );
}
