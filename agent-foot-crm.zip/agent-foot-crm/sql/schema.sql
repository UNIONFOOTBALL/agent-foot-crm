-- À exécuter dans Supabase : Project > SQL Editor > New query > Run

create extension if not exists "pgcrypto";

create table if not exists players (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text default 'Pro',
  position text,
  age int,
  nationality text,
  current_club text,
  niveau text,
  market_value text,
  contract_start date,
  contract_end date,
  phone text,
  notes text,
  created_at timestamptz default now()
);

create table if not exists contacts (
  id uuid primary key default gen_random_uuid(),
  club_name text,
  contact_name text,
  role text,
  phone text,
  email text,
  notes text,
  created_at timestamptz default now()
);

create table if not exists deals (
  id uuid primary key default gen_random_uuid(),
  player_name text,
  target_club text,
  stage text default 'Prospection',
  value text,
  deadline date,
  notes text,
  created_at timestamptz default now()
);

create table if not exists reminders (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  type text,
  due_date date,
  player_name text,
  notes text,
  done boolean default false,
  created_at timestamptz default now()
);

-- RLS activé mais sans policy pour le rôle "anon" : la base n'est accessible
-- que via nos routes API Next.js (clé service_role, gardée côté serveur).
alter table players enable row level security;
alter table contacts enable row level security;
alter table deals enable row level security;
alter table reminders enable row level security;
