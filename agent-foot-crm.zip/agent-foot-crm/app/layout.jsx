import { Oswald, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const oswald = Oswald({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-oswald" });
const inter = Inter({ subsets: ["latin"], weight: ["400", "500", "600", "700"], variable: "--font-inter" });
const mono = JetBrains_Mono({ subsets: ["latin"], weight: ["500", "600"], variable: "--font-mono" });

export const metadata = {
  title: "CRM Agent Foot",
  description: "Gestion de portefeuille joueurs, clubs et négociations",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body className={`${oswald.variable} ${inter.variable} ${mono.variable} font-sans`}>
        {children}
      </body>
    </html>
  );
}
