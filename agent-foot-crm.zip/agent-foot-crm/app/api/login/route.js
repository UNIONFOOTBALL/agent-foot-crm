import { NextResponse } from "next/server";

export async function POST(request) {
  const { password } = await request.json();
  if (password && password === process.env.CRM_SHARED_PASSWORD) {
    const res = NextResponse.json({ ok: true });
    res.cookies.set("crm_authed", "1", {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 30, // 30 jours
    });
    return res;
  }
  return NextResponse.json({ ok: false, error: "Mot de passe incorrect" }, { status: 401 });
}
