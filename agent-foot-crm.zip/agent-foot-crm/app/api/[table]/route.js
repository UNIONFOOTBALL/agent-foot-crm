import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabaseServer";

const ALLOWED_TABLES = ["players", "contacts", "deals", "reminders"];

function checkAuth(request) {
  return request.cookies.get("crm_authed")?.value === "1";
}

function checkTable(table) {
  return ALLOWED_TABLES.includes(table);
}

export async function GET(request, { params }) {
  if (!checkAuth(request)) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (!checkTable(params.table)) return NextResponse.json({ error: "unknown table" }, { status: 400 });
  const supabase = supabaseServer();
  const { data, error } = await supabase.from(params.table).select("*").order("created_at", { ascending: true });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ data });
}

export async function POST(request, { params }) {
  if (!checkAuth(request)) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (!checkTable(params.table)) return NextResponse.json({ error: "unknown table" }, { status: 400 });
  const body = await request.json();
  const supabase = supabaseServer();
  // Supports inserting a single row (object) or many rows at once (array) — used by the bulk import.
  const { data, error } = await supabase.from(params.table).insert(body).select();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ data });
}

export async function PUT(request, { params }) {
  if (!checkAuth(request)) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (!checkTable(params.table)) return NextResponse.json({ error: "unknown table" }, { status: 400 });
  const body = await request.json();
  const { id, ...patch } = body;
  if (!id) return NextResponse.json({ error: "missing id" }, { status: 400 });
  const supabase = supabaseServer();
  const { data, error } = await supabase.from(params.table).update(patch).eq("id", id).select();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ data });
}

export async function DELETE(request, { params }) {
  if (!checkAuth(request)) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (!checkTable(params.table)) return NextResponse.json({ error: "unknown table" }, { status: 400 });
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "missing id" }, { status: 400 });
  const supabase = supabaseServer();
  const { error } = await supabase.from(params.table).delete().eq("id", id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
